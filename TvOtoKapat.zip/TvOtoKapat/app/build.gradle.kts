plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.tvotokapat"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.tvotokapat"
        minSdk = 28   // GLOBAL_ACTION_LOCK_SCREEN için Android 9+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
