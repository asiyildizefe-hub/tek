package com.example.tvotokapat

import android.content.Context

object Prefs {
    // 0 = kapalı. İstediğiniz süreyi buradan değiştirebilirsiniz (ör. 310 yerine 300).
    val OPTIONS = listOf(0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 310)

    private fun sp(c: Context) = c.getSharedPreferences("tvotokapat", Context.MODE_PRIVATE)
    fun getMinutes(c: Context): Int = sp(c).getInt("minutes", 0)
    fun setMinutes(c: Context, m: Int) = sp(c).edit().putInt("minutes", m).apply()
}
