package com.example.tvotokapat

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val buttons = mutableMapOf<Int, Button>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(80, 48, 80, 48)
            setBackgroundColor(Color.parseColor("#101820"))
        }
        root.addView(TextView(this).apply {
            text = "TV Oto Kapat"; textSize = 32f; setTextColor(Color.WHITE)
        })
        status = TextView(this).apply { textSize = 18f; setTextColor(Color.LTGRAY); setPadding(0, 12, 0, 12) }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Erişilebilirlik ayarlarını aç (servisi etkinleştir)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            text = "Kumandadan hiç tuşa basılmazsa kapanma süresi:"
            textSize = 20f; setTextColor(Color.WHITE); setPadding(0, 24, 0, 8)
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Prefs.OPTIONS.forEach { m ->
            val b = Button(this).apply {
                setOnClickListener {
                    Prefs.setMinutes(this@MainActivity, m)
                    InactivityService.instance?.reset()
                    refresh()
                }
            }
            buttons[m] = b
            list.addView(b)
        }
        root.addView(ScrollView(this).apply { addView(list) })
        setContentView(root)
        buttons[Prefs.getMinutes(this)]?.requestFocus()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun label(m: Int): String = when {
        m == 0 -> "Kapalı"
        m < 60 -> "$m dakika"
        m % 60 == 0 -> "$m dakika (${m / 60} saat)"
        else -> "$m dakika (${m / 60} sa ${m % 60} dk)"
    }

    private fun refresh() {
        val selected = Prefs.getMinutes(this)
        buttons.forEach { (m, b) -> b.text = (if (m == selected) "✓  " else "     ") + label(m) }
        status.text = (if (isServiceEnabled()) "Servis: AÇIK ✔" else "Servis: KAPALI ✘ — önce aşağıdan etkinleştirin") +
            "\nSeçili süre: " + label(selected)
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, InactivityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(me, true) }
    }
}
