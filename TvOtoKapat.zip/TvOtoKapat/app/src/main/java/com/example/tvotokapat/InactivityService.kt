package com.example.tvotokapat

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class InactivityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val warn = Runnable {
        Toast.makeText(this, "TV 30 saniye içinde kapanacak. Bir tuşa basın.", Toast.LENGTH_LONG).show()
    }
    private val shutdown = Runnable { turnOff() }

    companion object {
        var instance: InactivityService? = null
    }

    override fun onServiceConnected() {
        instance = this
        reset()
    }

    // Kumandadan her tuş basımı sayacı sıfırlar
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) reset()
        return false // tuşu engelleme, normal çalışsın
    }

    fun reset() {
        handler.removeCallbacks(warn)
        handler.removeCallbacks(shutdown)
        val minutes = Prefs.getMinutes(this)
        if (minutes <= 0) return
        val ms = minutes * 60_000L
        if (ms > 30_000L) handler.postDelayed(warn, ms - 30_000L)
        handler.postDelayed(shutdown, ms)
    }

    private fun turnOff() {
        // Ekranı kapat / uyku moduna al
        performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        // Hâlâ açıksa güç menüsünü aç (bazı TV'lerde uyku seçeneği çıkar)
        handler.postDelayed({
            val pm = getSystemService(PowerManager::class.java)
            if (pm.isInteractive) performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
        }, 2500)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        instance = null
        super.onDestroy()
    }
}
